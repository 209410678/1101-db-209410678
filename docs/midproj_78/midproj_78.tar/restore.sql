--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE midproj_78;
--
-- Name: midproj_78; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE midproj_78 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Chinese (Traditional)_Taiwan.950';


ALTER DATABASE midproj_78 OWNER TO postgres;

\connect midproj_78

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: category_78; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_78 (
    id integer NOT NULL,
    name character varying,
    bookname character varying,
    remote_url character varying,
    link_url character varying,
    contant character varying
);


ALTER TABLE public.category_78 OWNER TO postgres;

--
-- Data for Name: category_78; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_78 (id, name, bookname, remote_url, link_url, contant) FROM stdin;
\.
COPY public.category_78 (id, name, bookname, remote_url, link_url, contant) FROM '$$PATH$$/2981.dat';

--
-- Name: category_78 category_78_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_78
    ADD CONSTRAINT category_78_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

